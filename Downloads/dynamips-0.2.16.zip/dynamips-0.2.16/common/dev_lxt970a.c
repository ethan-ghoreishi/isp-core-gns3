/*
 * 10/100 Mbps Ethernet PHY.
 *
 * Based on:
 *  Intel® LXT970A
 *  Dual-Speed Fast Ethernet Transceiver
 *  Order Number: 249099-001
 *  January 2001
 * Based on:
 *  IEEE Std 802.3-2008, Section 2
 */

#include "dev_lxt970a.h"

