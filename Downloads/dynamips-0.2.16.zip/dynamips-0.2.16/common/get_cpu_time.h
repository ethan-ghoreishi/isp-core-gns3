/*
 * Cisco router simulation platform.
 * Copyright (c) 2005,2006 Christophe Fillot (cf@utc.fr)
 *
 */

#ifndef __GET_CPU_TIME_H__
#define __GET_CPU_TIME_H__

double get_cpu_time();

#endif

