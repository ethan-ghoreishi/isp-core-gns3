/v1/interfaces
----------------------------------------------------------------------------------------------------------------------

.. contents::

GET /v1/interfaces
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
List all the network interfaces available on the server

Response status codes
**********************
- **200**: OK

Sample session
***************


.. literalinclude:: ../../examples/get_interfaces.txt

