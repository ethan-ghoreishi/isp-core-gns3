/v1/projects/{project_id}/iou/vms/{vm_id}/configs/save
----------------------------------------------------------------------------------------------------------------------

.. contents::

POST /v1/projects/**{project_id}**/iou/vms/**{vm_id}**/configs/save
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Save the startup and private configs content

Response status codes
**********************
- **200**: Configs saved
- **400**: Invalid request
- **404**: Instance doesn't exist

