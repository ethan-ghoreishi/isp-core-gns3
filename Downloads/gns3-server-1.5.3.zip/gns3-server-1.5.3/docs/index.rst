Welcome to API documentation!
======================================

.. WARNING::
   The API is not stable, feel free to post comments on our website
   https://gns3.com/

.. toctree::
    general
    glossary
    development


API Endpoints
~~~~~~~~~~~~~~~

.. toctree::
   :glob:
   :maxdepth: 2
   
   api/v1/*

